# 🦞 Feed the Lobster

An animated Solana shop where you buy food for **Klik** the lobster. Every purchase is a real on-chain SOL transaction that boosts your **Trust Score**.

## Features

- 🦞 **Animated SVG lobster** (Klik) with 10 different reaction animations
- 💳 **Real Solana transactions** via Phantom Wallet
- 🏆 **Trust Score system** — 7 levels from UNKNOWN to CHAMBER LEGEND
- 💛 **Optional tip** to creator on every purchase
- 📡 **Live session feed** of purchases
- 🌊 **Epic effects** — confetti, screen shake, gold lobster, royal overlay

## Tech Stack

- Next.js 14 (App Router)
- Tailwind CSS
- `@solana/web3.js` + `@solana/wallet-adapter-react`
- Phantom Wallet

## Setup

```bash
npm install
npm run dev
```

## Deploy to Vercel

1. Push to GitHub
2. Import repo in Vercel
3. Deploy (no env vars required — uses Solana mainnet by default)

Optional: set `NEXT_PUBLIC_RPC_URL` to your own RPC endpoint (Helius, QuickNode, etc.) for better performance.

## Wallet

All SOL goes to: `Ghz2RotTtZKJeUFFNVfYV8NrB6TW5ZkJKQGcVYx31PvD`

Non-custodial. No backend. Pure client-side Solana.
