'use client'

import { useCallback, useState } from 'react'
import { useConnection, useWallet } from '@solana/wallet-adapter-react'
import { PublicKey, SystemProgram, Transaction, LAMPORTS_PER_SOL } from '@solana/web3.js'
import { CREATOR_WALLET, SOLSCAN_BASE } from '@/lib/constants'

interface PaymentOptions {
  amountSol: number
  tipSol?: number
}

interface PaymentResult {
  signature: string
  explorerUrl: string
}

export function useSolanaPayment() {
  const { connection } = useConnection()
  const { publicKey, sendTransaction, connected } = useWallet()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const pay = useCallback(
    async ({ amountSol, tipSol = 0 }: PaymentOptions): Promise<PaymentResult> => {
      if (!publicKey || !connected) {
        throw new Error('Wallet not connected')
      }

      setLoading(true)
      setError(null)

      try {
        const totalSol = amountSol + tipSol
        const totalLamports = Math.round(totalSol * LAMPORTS_PER_SOL)

        const toPubkey = new PublicKey(CREATOR_WALLET)

        const tx = new Transaction().add(
          SystemProgram.transfer({
            fromPubkey: publicKey,
            toPubkey,
            lamports: totalLamports,
          })
        )

        const { blockhash } = await connection.getLatestBlockhash()
        tx.recentBlockhash = blockhash
        tx.feePayer = publicKey

        const signature = await sendTransaction(tx, connection)

        await connection.confirmTransaction(signature, 'confirmed')

        return {
          signature,
          explorerUrl: `${SOLSCAN_BASE}/${signature}`,
        }
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : 'Transaction failed'
        setError(msg)
        throw err
      } finally {
        setLoading(false)
      }
    },
    [publicKey, connected, connection, sendTransaction]
  )

  return { pay, loading, error, connected, publicKey }
}
