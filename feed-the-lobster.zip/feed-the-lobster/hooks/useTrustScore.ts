'use client'

import { useCallback, useEffect, useState } from 'react'
import { getTrustLevel } from '@/lib/items'

const TRUST_KEY_PREFIX = 'ftl_trust_'

export function useTrustScore(walletAddress: string | null) {
  const [score, setScore] = useState(0)
  const [prevLevel, setPrevLevel] = useState<string | null>(null)
  const [levelUp, setLevelUp] = useState<string | null>(null)

  useEffect(() => {
    if (!walletAddress) {
      setScore(0)
      return
    }
    const key = TRUST_KEY_PREFIX + walletAddress
    const stored = localStorage.getItem(key)
    setScore(stored ? parseInt(stored, 10) : 0)
  }, [walletAddress])

  const addScore = useCallback(
    (boost: number) => {
      if (!walletAddress) return
      const key = TRUST_KEY_PREFIX + walletAddress
      setScore((prev) => {
        const next = prev + boost
        localStorage.setItem(key, String(next))

        const prevLvl = getTrustLevel(prev)
        const nextLvl = getTrustLevel(next)

        if (nextLvl.label !== prevLvl.label && prevLvl.label !== null) {
          setLevelUp(nextLvl.label)
          setTimeout(() => setLevelUp(null), 4000)
        }

        setPrevLevel(prevLvl.label)
        return next
      })
    },
    [walletAddress]
  )

  const currentLevel = getTrustLevel(score)

  return { score, addScore, currentLevel, levelUp }
}
