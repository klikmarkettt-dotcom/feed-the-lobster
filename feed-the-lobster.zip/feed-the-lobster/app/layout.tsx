import type { Metadata } from 'next'
import './globals.css'
import { SolanaWalletProvider } from '@/components/WalletProvider'

export const metadata: Metadata = {
  title: 'Feed the Lobster 🦞 — Chamber Shop',
  description: 'Buy food for Klik the Lobster using Solana. Earn trust. Become a Chamber Legend.',
  openGraph: {
    title: 'Feed the Lobster 🦞',
    description: 'Buy food for Klik using SOL. Earn trust. Become a Chamber Legend.',
    type: 'website',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen font-mono antialiased" style={{ background: '#080305' }}>
        <SolanaWalletProvider>{children}</SolanaWalletProvider>
      </body>
    </html>
  )
}
