'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { useWallet } from '@solana/wallet-adapter-react'
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui'
import { LobsterSVG } from '@/components/LobsterSVG'
import { ShopItemCard } from '@/components/ShopItem'
import { BuyModal } from '@/components/BuyModal'
import { TrustBadge } from '@/components/TrustBadge'
import { LiveFeed, type FeedItem } from '@/components/LiveFeed'
import { useTrustScore } from '@/hooks/useTrustScore'
import { useSolanaPayment } from '@/hooks/useSolanaPayment'
import { SHOP_ITEMS, type ShopItem, type LobsterReaction } from '@/lib/items'

// ── Toast ──────────────────────────────────────────────────────────────────────

interface ToastMsg {
  id: number
  text: string
  type: 'success' | 'error' | 'levelup'
  href?: string
}

function Toasts({ toasts, remove }: { toasts: ToastMsg[]; remove: (id: number) => void }) {
  return (
    <div className="fixed top-4 right-4 z-50 flex flex-col gap-2 max-w-xs">
      {toasts.map((t) => (
        <div
          key={t.id}
          className="rounded-xl border px-4 py-3 text-sm font-medium cursor-pointer animate-slideUp transition-all"
          onClick={() => remove(t.id)}
          style={{
            background: t.type === 'success' ? 'rgba(10,30,10,0.95)' :
                        t.type === 'levelup' ? 'rgba(20,10,30,0.95)' :
                        'rgba(30,10,10,0.95)',
            borderColor: t.type === 'success' ? '#166534' :
                         t.type === 'levelup' ? '#7c3aed' :
                         '#7f1d1d',
            color: t.type === 'success' ? '#4ade80' :
                   t.type === 'levelup' ? '#c084fc' :
                   '#fca5a5',
            boxShadow: t.type === 'levelup' ? '0 0 20px rgba(124,58,237,0.4)' : 'none',
          }}
        >
          {t.text}
          {t.href && (
            <a
              href={t.href}
              target="_blank"
              rel="noreferrer"
              onClick={(e) => e.stopPropagation()}
              className="block text-xs underline opacity-60 hover:opacity-100 mt-1"
            >
              View on Solscan ↗
            </a>
          )}
        </div>
      ))}
    </div>
  )
}

// ── Confetti ───────────────────────────────────────────────────────────────────

function launchConfetti() {
  const colors = ['#FFD700', '#FF6B2B', '#E8271A', '#FF4422', '#FFF']
  const count = 80
  for (let i = 0; i < count; i++) {
    const el = document.createElement('div')
    el.className = 'confetti-particle'
    el.style.left = Math.random() * 100 + 'vw'
    el.style.background = colors[Math.floor(Math.random() * colors.length)]
    el.style.width = (6 + Math.random() * 10) + 'px'
    el.style.height = (6 + Math.random() * 10) + 'px'
    el.style.animationDuration = (2 + Math.random() * 3) + 's'
    el.style.animationDelay = Math.random() * 1 + 's'
    document.body.appendChild(el)
    setTimeout(() => el.remove(), 5000)
  }
}

// ── Main Page ──────────────────────────────────────────────────────────────────

export default function FeedTheLobsterPage() {
  const { publicKey } = useWallet()
  const walletAddress = publicKey?.toBase58() ?? null

  const { score, addScore, currentLevel, levelUp } = useTrustScore(walletAddress)
  const { pay, loading } = useSolanaPayment()

  const [selectedItem, setSelectedItem] = useState<ShopItem | null>(null)
  const [reaction, setReaction] = useState<LobsterReaction>('idle')
  const [speech, setSpeech] = useState('Feed me... 🦞')
  const [toasts, setToasts] = useState<ToastMsg[]>([])
  const [feed, setFeed] = useState<FeedItem[]>([])

  const toastId = useRef(0)

  const addToast = useCallback((text: string, type: ToastMsg['type'], href?: string) => {
    const id = ++toastId.current
    setToasts((prev) => [...prev, { id, text, type, href }])
    setTimeout(() => setToasts((prev) => prev.filter((t) => t.id !== id)), 5000)
  }, [])

  // Level-up notification
  useEffect(() => {
    if (levelUp) {
      addToast(`🎉 LEVEL UP! You are now ${levelUp}!`, 'levelup')
    }
  }, [levelUp, addToast])

  // Idle speech cycle
  useEffect(() => {
    if (reaction !== 'idle') return
    const idlePhrases = [
      'Feed me... 🦞',
      'I am hungry... 🌊',
      'SOL accepted 🦐',
      'Claws ready... 🦀',
      'Trust me... 🤝',
    ]
    const iv = setInterval(() => {
      setSpeech(idlePhrases[Math.floor(Math.random() * idlePhrases.length)])
    }, 4000)
    return () => clearInterval(iv)
  }, [reaction])

  async function handleBuy(tipSol: number) {
    if (!selectedItem) return

    try {
      const result = await pay({ amountSol: selectedItem.price, tipSol })

      // Trigger reaction
      setReaction(selectedItem.reaction)
      setSpeech(selectedItem.speech)

      // Special effects
      if (selectedItem.reaction === 'royal-feast') {
        launchConfetti()
      }

      // Trust score
      addScore(selectedItem.trustBoost)

      // Feed
      if (walletAddress) {
        const feedItem: FeedItem = {
          id: result.signature,
          wallet: walletAddress,
          itemName: selectedItem.name,
          itemEmoji: selectedItem.emoji,
          price: selectedItem.price,
          trustBoost: selectedItem.trustBoost,
          signature: result.signature,
          when: Date.now(),
        }
        setFeed((prev) => [feedItem, ...prev].slice(0, 10))
      }

      addToast(`✓ Fed! +${selectedItem.trustBoost} trust earned`, 'success', result.explorerUrl)
      setSelectedItem(null)
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Transaction failed'
      setReaction('sad')
      setSpeech('Oof... 😢')
      const shortMsg = msg.includes('rejected') ? 'Transaction rejected by user' :
                       msg.includes('funds') ? 'Insufficient funds' :
                       msg.includes('connect') ? 'Please connect wallet first' :
                       'Transaction failed'
      addToast(`✗ ${shortMsg}`, 'error')
      setSelectedItem(null)
    }
  }

  function handleReactionEnd() {
    setReaction('idle')
    setSpeech('Feed me... 🦞')
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ background: 'linear-gradient(180deg, #080305 0%, #0f0408 50%, #080305 100%)' }}>
      <Toasts toasts={toasts} remove={(id) => setToasts((p) => p.filter((t) => t.id !== id))} />

      {/* ── Header ── */}
      <header className="flex items-center justify-between px-4 py-3 border-b sticky top-0 z-30"
        style={{ borderColor: '#2a0a0a', background: 'rgba(8,3,5,0.95)', backdropFilter: 'blur(12px)' }}>
        <div>
          <h1 className="text-white font-bold tracking-widest text-base md:text-lg"
            style={{ fontFamily: 'Space Grotesk, sans-serif' }}>
            ☿ FEED THE LOBSTER
          </h1>
          <p className="text-zinc-700 text-xs">Klik is hungry. SOL welcome.</p>
        </div>

        <div className="flex items-center gap-3">
          {walletAddress && (
            <TrustBadge score={score} />
          )}
          <WalletMultiButton />
        </div>
      </header>

      {/* ── Main content ── */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 py-6 md:py-10">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8">

          {/* ── LEFT: Lobster + info ── */}
          <div className="lg:col-span-1 flex flex-col items-center gap-4">

            {/* Lobster */}
            <div className="w-full flex flex-col items-center py-6 px-4 rounded-2xl border relative"
              style={{
                background: 'radial-gradient(ellipse at center, #150808 0%, #080305 100%)',
                borderColor: '#2a0a0a',
                boxShadow: '0 0 40px rgba(155,34,34,0.1)',
              }}>
              {/* Scanline effect */}
              <div className="absolute inset-0 rounded-2xl opacity-5 pointer-events-none"
                style={{
                  backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.03) 4px)',
                }} />

              <LobsterSVG
                reaction={reaction}
                speech={speech}
                onReactionEnd={handleReactionEnd}
              />
            </div>

            {/* Trust score (mobile) */}
            {walletAddress && (
              <div className="lg:hidden w-full">
                <TrustBadge score={score} />
              </div>
            )}

            {/* Trust level guide */}
            <div className="w-full rounded-xl border p-4 space-y-2"
              style={{ borderColor: '#1a0808', background: '#0a0405' }}>
              <h3 className="text-zinc-600 text-xs uppercase tracking-widest mb-3">Trust Levels</h3>
              {[
                { emoji: '👑', label: 'CHAMBER LEGEND', range: '200+', color: '#FFD700' },
                { emoji: '🟣', label: 'LOBSTER FRIEND', range: '121–199', color: '#A855F7' },
                { emoji: '🔵', label: 'CHAMBER ALLY', range: '81–120', color: '#3B82F6' },
                { emoji: '🟢', label: 'TRUSTED', range: '61–80', color: '#22C55E' },
                { emoji: '🟡', label: 'MEMBER', range: '41–60', color: '#EAB308' },
                { emoji: '🟠', label: 'LURKER', range: '21–40', color: '#F97316' },
                { emoji: '🔴', label: 'UNKNOWN', range: '0–20', color: '#EF4444' },
              ].map((lvl) => (
                <div key={lvl.label} className="flex items-center gap-2 text-xs">
                  <span>{lvl.emoji}</span>
                  <span className="font-bold" style={{ color: lvl.color }}>{lvl.label}</span>
                  <span className="text-zinc-700 ml-auto font-mono">{lvl.range}</span>
                </div>
              ))}
            </div>
          </div>

          {/* ── RIGHT: Shop + Feed ── */}
          <div className="lg:col-span-2 space-y-6">

            {/* Wallet prompt */}
            {!walletAddress && (
              <div className="rounded-xl border border-dashed text-center py-8 px-4"
                style={{ borderColor: '#3a1010', background: '#0c0406' }}>
                <div className="text-4xl mb-3">🟣</div>
                <p className="text-zinc-400 font-semibold mb-2">Connect Phantom to Feed Klik</p>
                <p className="text-zinc-700 text-xs mb-4">Your trust score will be saved to your wallet address</p>
                <WalletMultiButton />
              </div>
            )}

            {/* Shop grid */}
            <div>
              <h2 className="text-zinc-500 text-xs uppercase tracking-widest mb-3 flex items-center gap-2">
                <span className="text-red-800">◆</span> Choose what to feed
              </h2>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-2 xl:grid-cols-3 gap-3">
                {SHOP_ITEMS.map((item) => (
                  <ShopItemCard
                    key={item.id}
                    item={item}
                    onClick={() => setSelectedItem(item)}
                    disabled={!walletAddress}
                  />
                ))}
              </div>
            </div>

            {/* Live feed */}
            <div className="rounded-xl border p-4" style={{ borderColor: '#1a0808', background: '#0a0405' }}>
              <h2 className="text-zinc-600 text-xs uppercase tracking-widest mb-3 flex items-center gap-2">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-800 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-red-700" />
                </span>
                Live Session Feed
              </h2>
              <LiveFeed events={feed} />
            </div>

          </div>
        </div>
      </main>

      {/* ── Footer ── */}
      <footer className="text-center py-6 border-t" style={{ borderColor: '#150608' }}>
        <p className="text-zinc-800 text-xs">
          All transactions go directly to the creator's Solana wallet. Non-custodial.
        </p>
        <p className="text-zinc-800 text-xs mt-1">
          <span className="font-mono">Ghz2RotTtZKJeUFFNVfYV8NrB6TW5ZkJKQGcVYx31PvD</span>
        </p>
      </footer>

      {/* ── Buy Modal ── */}
      {selectedItem && (
        <BuyModal
          item={selectedItem}
          onConfirm={handleBuy}
          onCancel={() => setSelectedItem(null)}
          loading={loading}
        />
      )}
    </div>
  )
}
