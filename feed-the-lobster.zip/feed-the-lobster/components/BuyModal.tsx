'use client'

import { useState } from 'react'
import type { ShopItem } from '@/lib/items'

interface BuyModalProps {
  item: ShopItem
  onConfirm: (tipSol: number) => void
  onCancel: () => void
  loading: boolean
}

const TIP_OPTIONS = [0, 0.01, 0.05] as const

export function BuyModal({ item, onConfirm, onCancel, loading }: BuyModalProps) {
  const [tip, setTip] = useState<number>(0)
  const [customTip, setCustomTip] = useState('')
  const [useCustom, setUseCustom] = useState(false)

  const activeTip = useCustom ? (parseFloat(customTip) || 0) : tip
  const total = item.price + activeTip

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div
        className="relative w-full max-w-sm rounded-2xl border overflow-hidden"
        style={{
          background: 'linear-gradient(135deg, #0a0505 0%, #140a0a 100%)',
          borderColor: '#5a1a1a',
          boxShadow: '0 0 60px rgba(180,30,20,0.2)',
        }}
      >
        {/* Header glow */}
        <div className="absolute inset-x-0 top-0 h-px" style={{ background: 'linear-gradient(90deg, transparent, #9B2222, transparent)' }} />

        <div className="p-6">
          {/* Item header */}
          <div className="flex items-start gap-4 mb-6">
            <span className="text-5xl">{item.emoji}</span>
            <div>
              <h3 className="text-white font-bold text-xl leading-tight">{item.name}</h3>
              <p className="text-zinc-500 text-sm mt-1">{item.description}</p>
              <div className="flex items-center gap-3 mt-2">
                <span className="text-red-400 text-xs border border-red-900 px-2 py-0.5 rounded-full font-mono">
                  +{item.trustBoost} TRUST
                </span>
              </div>
            </div>
          </div>

          {/* Price breakdown */}
          <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-4 mb-5 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-zinc-400">{item.name}</span>
              <span className="text-white font-mono">{item.price}◎</span>
            </div>

            {/* Tip selector */}
            <div className="pt-2 border-t border-zinc-800">
              <p className="text-zinc-500 text-xs mb-2 uppercase tracking-widest">💛 Tip creator</p>
              <div className="flex gap-2 flex-wrap">
                {TIP_OPTIONS.map((t) => (
                  <button
                    key={t}
                    onClick={() => { setTip(t); setUseCustom(false) }}
                    className={`text-xs px-3 py-1.5 rounded-lg border font-mono transition-all ${
                      !useCustom && tip === t
                        ? 'border-yellow-600 bg-yellow-900/40 text-yellow-400'
                        : 'border-zinc-700 text-zinc-500 hover:border-zinc-500'
                    }`}
                  >
                    {t === 0 ? 'No tip' : `${t}◎`}
                  </button>
                ))}
                <button
                  onClick={() => setUseCustom(true)}
                  className={`text-xs px-3 py-1.5 rounded-lg border font-mono transition-all ${
                    useCustom
                      ? 'border-yellow-600 bg-yellow-900/40 text-yellow-400'
                      : 'border-zinc-700 text-zinc-500 hover:border-zinc-500'
                  }`}
                >
                  Custom
                </button>
              </div>
              {useCustom && (
                <input
                  type="number"
                  value={customTip}
                  onChange={(e) => setCustomTip(e.target.value)}
                  placeholder="0.00"
                  step="0.01"
                  min="0"
                  className="mt-2 w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-yellow-600"
                />
              )}
            </div>

            {activeTip > 0 && (
              <div className="flex justify-between text-sm">
                <span className="text-yellow-600">Tip</span>
                <span className="text-yellow-400 font-mono">+{activeTip.toFixed(4)}◎</span>
              </div>
            )}

            <div className="flex justify-between font-bold border-t border-zinc-700 pt-2">
              <span className="text-white">Total</span>
              <span className="text-white font-mono">{total.toFixed(4)}◎ SOL</span>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex gap-3">
            <button
              onClick={onCancel}
              disabled={loading}
              className="flex-1 border border-zinc-700 text-zinc-400 rounded-xl py-3 text-sm hover:text-white hover:border-zinc-500 transition-colors disabled:opacity-40"
            >
              Cancel
            </button>
            <button
              onClick={() => onConfirm(activeTip)}
              disabled={loading}
              className="flex-1 rounded-xl py-3 text-sm font-bold text-white transition-all disabled:opacity-40 relative overflow-hidden"
              style={{
                background: loading
                  ? 'rgba(100,30,30,0.6)'
                  : 'linear-gradient(135deg, #7B1FA2 0%, #4A148C 100%)',
                boxShadow: loading ? 'none' : '0 0 20px rgba(123,31,162,0.5)',
              }}
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Confirming…
                </span>
              ) : (
                '🟣 Buy with Phantom'
              )}
            </button>
          </div>

          <p className="text-center text-zinc-700 text-xs mt-4">
            Tip address: Ghz2Rot…31PvD
          </p>
        </div>
      </div>
    </div>
  )
}
