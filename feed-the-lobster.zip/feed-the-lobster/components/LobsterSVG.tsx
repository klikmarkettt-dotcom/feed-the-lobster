'use client'

import { useEffect, useRef, useState } from 'react'
import type { LobsterReaction } from '@/lib/items'

interface LobsterSVGProps {
  reaction: LobsterReaction
  speech: string
  onReactionEnd?: () => void
}

export function LobsterSVG({ reaction, speech, onReactionEnd }: LobsterSVGProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const [isGold, setIsGold] = useState(false)
  const [showCrown, setShowCrown] = useState(false)
  const [bodyClass, setBodyClass] = useState('animate-bob')
  const [showRoyalOverlay, setShowRoyalOverlay] = useState(false)

  useEffect(() => {
    if (reaction === 'idle') {
      setBodyClass('animate-bob')
      setIsGold(false)
      setShowCrown(false)
      setShowRoyalOverlay(false)
      return
    }

    const classMap: Record<LobsterReaction, string> = {
      idle: 'animate-bob',
      nibble: 'animate-nibble',
      'happy-dance': 'animate-wiggle',
      'excited-claws': 'animate-wiggle',
      'content-sway': 'animate-sway',
      slurp: 'animate-sway',
      'big-celebration': 'animate-spin360',
      'mega-dance': 'animate-megaDance',
      crown: 'animate-bob',
      'screen-shake': 'animate-shake',
      'royal-feast': 'animate-megaDance',
      sad: 'animate-droopIn',
    }

    setBodyClass(classMap[reaction] || 'animate-bob')

    if (reaction === 'crown') {
      setShowCrown(true)
      setTimeout(() => setShowCrown(false), 5000)
    }

    if (reaction === 'royal-feast') {
      setIsGold(true)
      setShowRoyalOverlay(true)
      setTimeout(() => {
        setShowRoyalOverlay(false)
        setTimeout(() => {
          setIsGold(false)
          setBodyClass('animate-bob')
          onReactionEnd?.()
        }, 500)
      }, 5000)
      return
    }

    if (reaction === 'screen-shake') {
      document.body.style.animation = 'shake 0.8s ease-in-out'
      setTimeout(() => {
        document.body.style.animation = ''
      }, 800)
    }

    const duration: Record<LobsterReaction, number> = {
      idle: 0,
      nibble: 1600,
      'happy-dance': 600,
      'excited-claws': 600,
      'content-sway': 1200,
      slurp: 1200,
      'big-celebration': 800,
      'mega-dance': 3000,
      crown: 5000,
      'screen-shake': 800,
      'royal-feast': 6000,
      sad: 2000,
    }

    const t = setTimeout(() => {
      setBodyClass('animate-bob')
      onReactionEnd?.()
    }, duration[reaction] || 1500)

    return () => clearTimeout(t)
  }, [reaction, onReactionEnd])

  const bodyColor = isGold ? '#FFD700' : '#C0392B'
  const shellColor = isGold ? '#F4C430' : '#9B2222'
  const clawColor = isGold ? '#FFD700' : '#B03020'
  const eyeColor = '#000000'
  const antennaeColor = isGold ? '#DAA520' : '#8B1A1A'

  return (
    <div className="relative flex flex-col items-center" ref={containerRef}>
      {/* Royal feast overlay */}
      {showRoyalOverlay && (
        <div className="fixed inset-0 z-40 pointer-events-none flex items-center justify-center"
          style={{ background: 'radial-gradient(ellipse at center, rgba(255,215,0,0.15) 0%, rgba(0,0,0,0.6) 100%)' }}>
          <div className="text-center animate-scaleIn">
            <div className="text-8xl mb-4">👑</div>
            <div className="text-4xl font-bold text-yellow-400 tracking-widest" style={{ textShadow: '0 0 30px gold' }}>
              CHAMBER LEGEND
            </div>
          </div>
        </div>
      )}

      {/* Crown */}
      {showCrown && (
        <div className="absolute -top-12 left-1/2 -translate-x-1/2 animate-scaleIn z-10 text-4xl">
          ✨👑✨
        </div>
      )}

      {/* Speech bubble */}
      <div className="mb-4 relative">
        <div
          className="px-4 py-2 rounded-2xl text-sm font-bold text-white border transition-all duration-300"
          style={{
            background: 'rgba(20,8,8,0.9)',
            borderColor: isGold ? '#FFD700' : '#9B2222',
            boxShadow: isGold ? '0 0 20px rgba(255,215,0,0.4)' : '0 0 10px rgba(155,34,34,0.3)',
            color: isGold ? '#FFD700' : '#FFF',
          }}
        >
          {speech}
        </div>
        {/* Speech bubble tail */}
        <div
          className="absolute left-1/2 -translate-x-1/2 w-0 h-0"
          style={{
            top: '100%',
            borderLeft: '8px solid transparent',
            borderRight: '8px solid transparent',
            borderTop: `8px solid ${isGold ? '#FFD700' : '#9B2222'}`,
          }}
        />
      </div>

      {/* Lobster SVG */}
      <div className={`${bodyClass} cursor-pointer select-none`}
        style={{ filter: isGold ? 'drop-shadow(0 0 20px rgba(255,215,0,0.8))' : 'drop-shadow(0 0 8px rgba(200,60,40,0.4))' }}>
        <svg
          viewBox="0 0 200 220"
          width="200"
          height="220"
          xmlns="http://www.w3.org/2000/svg"
          aria-label="Klik the lobster"
        >
          {/* === ANTENNAE === */}
          <line x1="80" y1="30" x2="40" y2="0" stroke={antennaeColor} strokeWidth="2.5" strokeLinecap="round" />
          <line x1="82" y1="28" x2="50" y2="-5" stroke={antennaeColor} strokeWidth="1.5" strokeLinecap="round" />
          <line x1="120" y1="30" x2="160" y2="0" stroke={antennaeColor} strokeWidth="2.5" strokeLinecap="round" />
          <line x1="118" y1="28" x2="150" y2="-5" stroke={antennaeColor} strokeWidth="1.5" strokeLinecap="round" />

          {/* === LEFT BIG CLAW === */}
          <g>
            {/* arm */}
            <ellipse cx="52" cy="95" rx="12" ry="8" fill={clawColor} transform="rotate(-30 52 95)" />
            {/* lower claw */}
            <ellipse cx="30" cy="108" rx="20" ry="10" fill={clawColor} transform="rotate(-20 30 108)" />
            {/* upper claw pincer */}
            <ellipse cx="22" cy="98" rx="15" ry="7" fill={bodyColor} transform="rotate(-30 22 98)" />
            {/* claw tip lower */}
            <ellipse cx="14" cy="116" rx="8" ry="5" fill={shellColor} transform="rotate(-20 14 116)" />
          </g>

          {/* === RIGHT BIG CLAW === */}
          <g>
            <ellipse cx="148" cy="95" rx="12" ry="8" fill={clawColor} transform="rotate(30 148 95)" />
            <ellipse cx="170" cy="108" rx="20" ry="10" fill={clawColor} transform="rotate(20 170 108)" />
            <ellipse cx="178" cy="98" rx="15" ry="7" fill={bodyColor} transform="rotate(30 178 98)" />
            <ellipse cx="186" cy="116" rx="8" ry="5" fill={shellColor} transform="rotate(20 186 116)" />
          </g>

          {/* === MAIN BODY (cephalothorax) === */}
          <ellipse cx="100" cy="90" rx="46" ry="52" fill={bodyColor} />
          {/* shell segments */}
          <ellipse cx="100" cy="72" rx="36" ry="16" fill={shellColor} opacity="0.6" />
          <ellipse cx="100" cy="88" rx="40" ry="14" fill={shellColor} opacity="0.4" />
          <ellipse cx="100" cy="104" rx="36" ry="12" fill={shellColor} opacity="0.3" />

          {/* === HEAD / ROSTRUM === */}
          <ellipse cx="100" cy="45" rx="32" ry="24" fill={bodyColor} />
          {/* rostrum spike */}
          <polygon points="100,10 94,32 106,32" fill={clawColor} />

          {/* === EYES === */}
          <circle cx="84" cy="38" r="8" fill={isGold ? '#8B6914' : '#1a1a1a'} />
          <circle cx="116" cy="38" r="8" fill={isGold ? '#8B6914' : '#1a1a1a'} />
          <circle cx="84" cy="38" r="4" fill={eyeColor} />
          <circle cx="116" cy="38" r="4" fill={eyeColor} />
          <circle cx="86" cy="36" r="1.5" fill="white" opacity="0.8" />
          <circle cx="118" cy="36" r="1.5" fill="white" opacity="0.8" />

          {/* === WALKING LEGS === */}
          {/* Left legs */}
          <line x1="68" y1="110" x2="42" y2="135" stroke={clawColor} strokeWidth="3" strokeLinecap="round" />
          <line x1="72" y1="118" x2="46" y2="148" stroke={clawColor} strokeWidth="3" strokeLinecap="round" />
          <line x1="70" y1="128" x2="50" y2="158" stroke={clawColor} strokeWidth="3" strokeLinecap="round" />
          {/* Right legs */}
          <line x1="132" y1="110" x2="158" y2="135" stroke={clawColor} strokeWidth="3" strokeLinecap="round" />
          <line x1="128" y1="118" x2="154" y2="148" stroke={clawColor} strokeWidth="3" strokeLinecap="round" />
          <line x1="130" y1="128" x2="150" y2="158" stroke={clawColor} strokeWidth="3" strokeLinecap="round" />

          {/* === ABDOMEN (tail) === */}
          <ellipse cx="100" cy="148" rx="32" ry="22" fill={bodyColor} />
          <ellipse cx="100" cy="165" rx="26" ry="18" fill={bodyColor} />
          <ellipse cx="100" cy="180" rx="20" ry="14" fill={bodyColor} />
          {/* segment lines */}
          <ellipse cx="100" cy="150" rx="28" ry="8" fill={shellColor} opacity="0.3" />
          <ellipse cx="100" cy="165" rx="22" ry="7" fill={shellColor} opacity="0.3" />
          <ellipse cx="100" cy="178" rx="17" ry="6" fill={shellColor} opacity="0.3" />

          {/* === TAIL FAN === */}
          <ellipse cx="80" cy="196" rx="14" ry="7" fill={clawColor} transform="rotate(-20 80 196)" />
          <ellipse cx="100" cy="200" rx="14" ry="7" fill={clawColor} />
          <ellipse cx="120" cy="196" rx="14" ry="7" fill={clawColor} transform="rotate(20 120 196)" />
          <ellipse cx="65" cy="192" rx="10" ry="5" fill={shellColor} transform="rotate(-35 65 192)" />
          <ellipse cx="135" cy="192" rx="10" ry="5" fill={shellColor} transform="rotate(35 135 192)" />

          {/* Glow effect when gold */}
          {isGold && (
            <ellipse cx="100" cy="110" rx="55" ry="100" fill="url(#goldGlow)" opacity="0.3" />
          )}

          <defs>
            <radialGradient id="goldGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#FFD700" stopOpacity="0.6" />
              <stop offset="100%" stopColor="#FFD700" stopOpacity="0" />
            </radialGradient>
          </defs>
        </svg>
      </div>

      {/* Name tag */}
      <p className="mt-2 text-xs font-mono tracking-widest" style={{ color: isGold ? '#DAA520' : '#9B2222' }}>
        — Klik —
      </p>
    </div>
  )
}
