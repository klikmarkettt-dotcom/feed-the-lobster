'use client'

import type { ShopItem } from '@/lib/items'

interface ShopItemProps {
  item: ShopItem
  onClick: () => void
  disabled?: boolean
}

export function ShopItemCard({ item, onClick, disabled }: ShopItemProps) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="group relative border border-zinc-800 hover:border-red-800 bg-zinc-900/60 hover:bg-red-950/20 rounded-xl p-3 text-left transition-all duration-200 disabled:opacity-40 disabled:cursor-not-allowed overflow-hidden"
    >
      {/* Hover glow */}
      <div className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
        style={{ boxShadow: 'inset 0 0 20px rgba(200,50,30,0.1)' }} />

      <div className="text-3xl mb-2 group-hover:scale-110 transition-transform duration-200 inline-block">
        {item.emoji}
      </div>
      <div className="text-white font-semibold text-sm leading-tight mb-0.5">{item.name}</div>
      <div className="flex items-center justify-between mt-1.5">
        <span className="text-zinc-300 text-sm font-mono font-bold">{item.price}◎</span>
        <span className="text-xs text-red-400 opacity-0 group-hover:opacity-100 transition-opacity font-bold">
          +{item.trustBoost}
        </span>
      </div>
    </button>
  )
}
