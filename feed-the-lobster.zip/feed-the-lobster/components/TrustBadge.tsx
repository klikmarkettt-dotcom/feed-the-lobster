'use client'

import { getTrustLevel, TRUST_LEVELS } from '@/lib/items'

interface TrustBadgeProps {
  score: number
}

export function TrustBadge({ score }: TrustBadgeProps) {
  const level = getTrustLevel(score)

  // Find next level for progress bar
  const currentLevelIndex = TRUST_LEVELS.findIndex((l) => l.label === level.label)
  const nextLevel = TRUST_LEVELS[currentLevelIndex - 1]

  const progressMin = level.min
  const progressMax = nextLevel?.min ?? progressMin + 100
  const progress = nextLevel
    ? Math.min(100, ((score - progressMin) / (progressMax - progressMin)) * 100)
    : 100

  return (
    <div className={`flex flex-col gap-1.5 px-3 py-2 rounded-lg border ${level.border} ${level.bg} min-w-[160px]`}>
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs font-mono text-zinc-400 uppercase tracking-widest">Trust</span>
        <span className={`text-xs font-bold ${level.text}`}>
          {level.emoji} {level.label}
        </span>
      </div>
      <div className="flex items-center gap-2">
        <span className={`text-2xl font-bold tabular-nums ${level.text}`}>{score}</span>
        {nextLevel && (
          <span className="text-xs text-zinc-600 mt-1">
            → {nextLevel.min}
          </span>
        )}
      </div>
      {/* Progress bar */}
      <div className="h-1.5 rounded-full bg-zinc-800 overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-700"
          style={{
            width: `${progress}%`,
            background: level.color,
            boxShadow: `0 0 6px ${level.color}`,
          }}
        />
      </div>
    </div>
  )
}
